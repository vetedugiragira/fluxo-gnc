@echo off
cd /d "%~dp0"
if not exist .venv python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
start http://127.0.0.1:8000
.venv\Scripts\python -m uvicorn main:app --host 127.0.0.1 --port 8000
